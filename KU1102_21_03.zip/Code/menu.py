harga = [5000, 5000, 5000, 5000, 5000, 5000, 10000, 10000, 10000, 10000, 10000, 15000, 15000, 15000, 15000]
menu = ["Aqua","Pucuk Harum","Mizone","Fanta","Sprite","Pepsi","Ichi Ocha","Frestea","Buavita","Floridina","Coolant","Joy Tea","Tebs","Pocari Sweat","Teh Botol Sosro"] 
item_id = [i for i in range(15)]
